import os,re,requests
from colorama import Fore,init, Style
from multiprocessing.dummy import Pool
bl = Fore.BLACK
wh = Fore.WHITE
yl = Fore.YELLOW
red = Fore.RED
res = Style.RESET_ALL
gr = Fore.GREEN
ble = Fore.BLUE

def screen_clear():
    _ = os.system('cls')

if os.name == "nt":
	os.system("cls")
else:
	os.system("clear")

init(convert=True)

class settings:
	y = Fore.YELLOW
	r = Fore.RED
	b = Fore.BLUE


def clean():
	lines_seen = set()
	outfile = open('sites.txt', "a")
	infile = open('sitelist.txt', "r")
	for line in infile:
		if line not in lines_seen:
			outfile.write(line)
			lines_seen.add(line)
	outfile.close()
	infile.close()
	if os.name == "nt":
		os.system("del sitelist.txt")
	else:
		os.system("rm -rf sitelist.txt")
	print("[{}+{}] Duplicate sites removed successfully!".format(settings.r,settings.y))
	print("\n[{}+{}] Sites saved as {}sites.txt{}!".format(settings.r,settings.y,settings.b,settings.y))


binglist = {"http://www.bing.com/search?q=&count=50&first=1",
"http://www.bing.com/search?q=&count=50&first=51",
"http://www.bing.com/search?q=&count=50&first=101",
"http://www.bing.com/search?q=&count=50&first=151",
"http://www.bing.com/search?q=&count=50&first=201",
"http://www.bing.com.br/search?q=&count=50&first=1",
"http://www.bing.com.br/search?q=&count=50&first=51",
"http://www.bing.com.br/search?q=&count=50&first=101",
"http://www.bing.at/search?q=&count=50&first=1",
"http://www.bing.at/search?q=&count=50&first=51",
"http://www.bing.at/search?q=&count=50&first=101",
"http://www.bing.be/search?q=&count=50&first=1",
"http://www.bing.be/search?q=&count=50&first=51",
"http://www.bing.be/search?q=&count=50&first=101",
"http://www.bing.cl/search?q=&count=50&first=1",
"http://www.bing.cl/search?q=&count=50&first=51",
"http://www.bing.cl/search?q=&count=50&first=101",
"http://www.bing.co.at/search?q=&count=50&first=1",
"http://www.bing.co.at/search?q=&count=50&first=51",
"http://www.bing.co.at/search?q=&count=50&first=101",
"http://www.bing.com.au/search?q=&count=50&first=1",
"http://www.bing.com.au/search?q=&count=50&first=51",
"http://www.bing.com.au/search?q=&count=50&first=101",
"http://www.bing.com.cn/search?q=&count=50&first=1",
"http://www.bing.com.cn/search?q=&count=50&first=51",
"http://www.bing.com.cn/search?q=&count=50&first=101",
"http://www.bing.cz/search?q=&count=50&first=1",
"http://www.bing.cz/search?q=&count=50&first=51",
"http://www.bing.cz/search?q=&count=50&first=101",
"http://www.bing.de/search?q=&count=50&first=1",
"http://www.bing.de/search?q=&count=50&first=51",
"http://www.bing.de/search?q=&count=50&first=101",
"http://www.bing.dk/search?q=&count=50&first=1",
"http://www.bing.dk/search?q=&count=50&first=51",
"http://www.bing.dk/search?q=&count=50&first=101",
"http://www.bing.ca/search?q=&count=50&first=1",
"http://www.bing.ca/search?q=&count=50&first=51",
"http://www.bing.ca/search?q=&count=50&first=101",
"http://www.bing.sg/search?q=&count=50&first=1",
"http://www.bing.sg/search?q=&count=50&first=51",
"http://www.bing.sg/search?q=&count=50&first=101",
"http://www.bing.se/search?q=&count=50&first=1",
"http://www.bing.se/search?q=&count=50&first=51",
"http://www.bing.se/search?q=&count=50&first=101",
"http://www.bing.pl/search?q=&count=50&first=1",
"http://www.bing.pl/search?q=&count=50&first=51",
"http://www.bing.pl/search?q=&count=50&first=101",
"http://www.bing.no/search?q=&count=50&first=1",
"http://www.bing.no/search?q=&count=50&first=51",
"http://www.bing.no/search?q=&count=50&first=101",
"http://www.bing.nl/search?q=&count=50&first=1",
"http://www.bing.nl/search?q=&count=50&first=51",
"http://www.bing.nl/search?q=&count=50&first=101",
"http://www.bing.net.nz/search?q=&count=50&first=1",
"http://www.bing.net.nz/search?q=&count=50&first=51",
"http://www.bing.net.nz/search?q=&count=50&first=101",
"http://www.bing.lv/search?q=&count=50&first=1",
"http://www.bing.lv/search?q=&count=50&first=51",
"http://www.bing.lv/search?q=&count=50&first=101",
"http://www.bing.lt/search?q=&count=50&first=1",
"http://www.bing.lt/search?q=&count=50&first=51",
"http://www.bing.lt/search?q=&count=50&first=101",
"http://www.bing.it/search?q=&count=50&first=1",
"http://www.bing.it/search?q=&count=50&first=51",
"http://www.bing.it/search?q=&count=50&first=101",
"http://www.bing.is/search?q=&count=50&first=1",
"http://www.bing.is/search?q=&count=50&first=51",
"http://www.bing.is/search?q=&count=50&first=101",
"http://www.bing.in/search?q=&count=50&first=1",
"http://www.bing.in/search?q=&count=50&first=51",
"http://www.bing.in/search?q=&count=50&first=101",
"http://www.bing.ie/search?q=&count=50&first=1",
"http://www.bing.ie/search?q=&count=50&first=51",
"http://www.bing.ie/search?q=&count=50&first=101",
"http://www.bing.hu/search?q=&count=50&first=1",
"http://www.bing.hu/search?q=&count=50&first=51",
"http://www.bing.hu/search?q=&count=50&first=101",
"http://www.bing.fr/search?q=&count=50&first=1",
"http://www.bing.fr/search?q=&count=50&first=51",
"http://www.bing.fr/search?q=&count=50&first=101",
"http://www.bing.com.sg/search?q=&count=50&first=1",
"http://www.bing.com.sg/search?q=&count=50&first=51",
"http://www.bing.com.sg/search?q=&count=50&first=101",
"http://www.bing.co.uk/search?q=&count=50&first=1",
"http://www.bing.co.uk/search?q=&count=50&first=51",
"http://www.bing.co.uk/search?q=&count=50&first=101",
"http://www.bing.co.nz/search?q=&count=50&first=1",
"http://www.bing.co.nz/search?q=&count=50&first=51",
"http://www.bing.co.nz/search?q=&count=50&first=101",
"http://www.bing.co.jp/search?q=&count=50&first=1",
"http://www.bing.co.jp/search?q=&count=50&first=51",
"http://www.bing.co.jp/search?q=&count=50&first=101",
"http://www.bing.ch/search?q=&count=50&first=1",
"http://www.bing.ch/search?q=&count=50&first=51",
"http://www.bing.ch/search?q=&count=50&first=101",
"http://www.bing.com.tr/search?q=&count=50&first=1",
"http://www.bing.com.tr/search?q=&count=50&first=51",
"http://www.bing.com.tr/search?q=&count=50&first=101",
"http://www.bing.com.pr/search?q=&count=50&first=1",
"http://www.bing.com.pr/search?q=&count=50&first=51",
"http://www.bing.com.pr/search?q=&count=50&first=101",
"http://www.bing.com.ar/search?q=&count=50&first=1",
"http://www.bing.com.ar/search?q=&count=50&first=51",
"http://www.bing.com.ar/search?q=&count=50&first=101",
"http://www.bing.com.co/search?q=&count=50&first=1",
"http://www.bing.com.co/search?q=&count=50&first=51",
"http://www.bing.com.co/search?q=&count=50&first=101",
"http://www.bing.com.es/search?q=&count=50&first=1",
"http://www.bing.com.es/search?q=&count=50&first=51",
"http://www.bing.com.es/search?q=&count=50&first=101",
"http://www.bing.fi/search?q=&count=50&first=1",
"http://www.bing.fi/search?q=&count=50&first=51",
"http://www.bing.fi/search?q=&count=50&first=101",
"http://www.bing.bo/search?q=&count=50&first=1",
"http://www.bing.bo/search?q=&count=50&first=51",
"http://www.bing.bo/search?q=&count=50&first=101",
"http://www.bing.com.do/search?q=&count=50&first=1",
"http://www.bing.com.do/search?q=&count=50&first=51",
"http://www.bing.com.do/search?q=&count=50&first=101",
"http://www.bing.gr/search?q=&count=50&first=1",
"http://www.bing.gr/search?q=&count=50&first=51",
"http://www.bing.gr/search?q=&count=50&first=101",
"http://www.bing.com.hk/search?q=&count=50&first=1",
"http://www.bing.com.hk/search?q=&count=50&first=51",
"http://www.bing.com.hk/search?q=&count=50&first=101",
"http://www.bing.com.hr/search?q=&count=50&first=1",
"http://www.bing.com.hr/search?q=&count=50&first=51",
"http://www.bing.com.hr/search?q=&count=50&first=101",
"http://www.bing.com.mx/search?q=&count=50&first=1",
"http://www.bing.com.mx/search?q=&count=50&first=51",
"http://www.bing.com.mx/search?q=&count=50&first=101",
"http://www.bing.com.my/search?q=&count=50&first=1",
"http://www.bing.com.my/search?q=&count=50&first=51",
"http://www.bing.com.my/search?q=&count=50&first=101",
"http://www.bing.ph/search?q=&count=50&first=1",
"http://www.bing.ph/search?q=&count=50&first=51",
"http://www.bing.ph/search?q=&count=50&first=101",
"http://www.bing.com.pr/search?q=&count=50&first=1",
"http://www.bing.com.pr/search?q=&count=50&first=51",
"http://www.bing.com.pr/search?q=&count=50&first=101",
"http://www.bing.pt/search?q=&count=50&first=1",
"http://www.bing.pt/search?q=&count=50&first=51",
"http://www.bing.pt/search?q=&count=50&first=101",
"http://www.bing.com.ro/search?q=&count=50&first=1",
"http://www.bing.com.ro/search?q=&count=50&first=51",
"http://www.bing.com.ro/search?q=&count=50&first=101",
"http://www.bing.ru/search?q=&count=50&first=1",
"http://www.bing.ru/search?q=&count=50&first=51",
"http://www.bing.ru/search?q=&count=50&first=101",
"http://www.bing.com.sa/search?q=&count=50&first=1",
"http://www.bing.com.sa/search?q=&count=50&first=51",
"http://www.bing.com.sa/search?q=&count=50&first=101",
"http://www.bing.si/search?q=&count=50&first=1",
"http://www.bing.si/search?q=&count=50&first=51",
"http://www.bing.si/search?q=&count=50&first=101",
"http://www.bing.sk/search?q=&count=50&first=1",
"http://www.bing.sk/search?q=&count=50&first=51",
"http://www.bing.sk/search?q=&count=50&first=101",
"http://www.bing.com.ua/search?q=&count=50&first=1",
"http://www.bing.com.ua/search?q=&count=50&first=51",
"http://www.bing.com.ua/search?q=&count=50&first=101",
"http://www.bing.com.uy/search?q=&count=50&first=1",
"http://www.bing.com.uy/search?q=&count=50&first=51",
"http://www.bing.com.uy/search?q=&count=50&first=101",
"http://www.bing.vn/search?q=&count=50&first=1",
"http://www.bing.vn/search?q=&count=50&first=51",
"http://www.bing.vn/search?q=&count=50&first=101",
"http://www.google.com/search?q=&count=50&first=1",
"http://www.google.com/search?q=&count=50&first=51",
"http://www.google.com/search?q=&count=50&first=101",
"http://www.google.com/search?q=&count=50&first=151",
"http://www.google.com/search?q=&count=50&first=201",
"http://www.google.com.br/search?q=&count=50&first=1",
"http://www.google.com.br/search?q=&count=50&first=51",
"http://www.google.com.br/search?q=&count=50&first=101",
"http://www.google.at/search?q=&count=50&first=1",
"http://www.google.at/search?q=&count=50&first=51",
"http://www.google.at/search?q=&count=50&first=101",
"http://www.google.be/search?q=&count=50&first=1",
"http://www.google.be/search?q=&count=50&first=51",
"http://www.google.be/search?q=&count=50&first=101",
"http://www.google.cl/search?q=&count=50&first=1",
"http://www.google.cl/search?q=&count=50&first=51",
"http://www.google.cl/search?q=&count=50&first=101",
"http://www.google.co.at/search?q=&count=50&first=1",
"http://www.google.co.at/search?q=&count=50&first=51",
"http://www.google.co.at/search?q=&count=50&first=101",
"http://www.google.com.au/search?q=&count=50&first=1",
"http://www.google.com.au/search?q=&count=50&first=51",
"http://www.google.com.au/search?q=&count=50&first=101",
"http://www.google.com.cn/search?q=&count=50&first=1",
"http://www.google.com.cn/search?q=&count=50&first=51",
"http://www.google.com.cn/search?q=&count=50&first=101",
"http://www.google.cz/search?q=&count=50&first=1",
"http://www.google.cz/search?q=&count=50&first=51",
"http://www.google.cz/search?q=&count=50&first=101",
"http://www.google.de/search?q=&count=50&first=1",
"http://www.google.de/search?q=&count=50&first=51",
"http://www.google.de/search?q=&count=50&first=101",
"http://www.google.dk/search?q=&count=50&first=1",
"http://www.google.dk/search?q=&count=50&first=51",
"http://www.google.dk/search?q=&count=50&first=101",
"http://www.google.ca/search?q=&count=50&first=1",
"http://www.google.ca/search?q=&count=50&first=51",
"http://www.google.ca/search?q=&count=50&first=101",
"http://www.google.sg/search?q=&count=50&first=1",
"http://www.google.sg/search?q=&count=50&first=51",
"http://www.google.sg/search?q=&count=50&first=101",
"http://www.google.se/search?q=&count=50&first=1",
"http://www.google.se/search?q=&count=50&first=51",
"http://www.google.se/search?q=&count=50&first=101",
"http://www.google.pl/search?q=&count=50&first=1",
"http://www.google.pl/search?q=&count=50&first=51",
"http://www.google.pl/search?q=&count=50&first=101",
"http://www.google.no/search?q=&count=50&first=1",
"http://www.google.no/search?q=&count=50&first=51",
"http://www.google.no/search?q=&count=50&first=101",
"http://www.google.nl/search?q=&count=50&first=1",
"http://www.google.nl/search?q=&count=50&first=51",
"http://www.google.nl/search?q=&count=50&first=101",
"http://www.google.net.nz/search?q=&count=50&first=1",
"http://www.google.net.nz/search?q=&count=50&first=51",
"http://www.google.net.nz/search?q=&count=50&first=101",
"http://www.google.lv/search?q=&count=50&first=1",
"http://www.google.lv/search?q=&count=50&first=51",
"http://www.google.lv/search?q=&count=50&first=101",
"http://www.google.lt/search?q=&count=50&first=1",
"http://www.google.lt/search?q=&count=50&first=51",
"http://www.google.lt/search?q=&count=50&first=101",
"http://www.google.it/search?q=&count=50&first=1",
"http://www.google.it/search?q=&count=50&first=51",
"http://www.google.it/search?q=&count=50&first=101",
"http://www.google.is/search?q=&count=50&first=1",
"http://www.google.is/search?q=&count=50&first=51",
"http://www.google.is/search?q=&count=50&first=101",
"http://www.google.in/search?q=&count=50&first=1",
"http://www.google.in/search?q=&count=50&first=51",
"http://www.google.in/search?q=&count=50&first=101",
"http://www.google.ie/search?q=&count=50&first=1",
"http://www.google.ie/search?q=&count=50&first=51",
"http://www.google.ie/search?q=&count=50&first=101",
"http://www.google.hu/search?q=&count=50&first=1",
"http://www.google.hu/search?q=&count=50&first=51",
"http://www.google.hu/search?q=&count=50&first=101",
"http://www.google.fr/search?q=&count=50&first=1",
"http://www.google.fr/search?q=&count=50&first=51",
"http://www.google.fr/search?q=&count=50&first=101",
"http://www.google.com.sg/search?q=&count=50&first=1",
"http://www.google.com.sg/search?q=&count=50&first=51",
"http://www.google.com.sg/search?q=&count=50&first=101",
"http://www.google.co.uk/search?q=&count=50&first=1",
"http://www.google.co.uk/search?q=&count=50&first=51",
"http://www.google.co.uk/search?q=&count=50&first=101",
"http://www.google.co.nz/search?q=&count=50&first=1",
"http://www.google.co.nz/search?q=&count=50&first=51",
"http://www.google.co.nz/search?q=&count=50&first=101",
"http://www.google.co.jp/search?q=&count=50&first=1",
"http://www.google.co.jp/search?q=&count=50&first=51",
"http://www.google.co.jp/search?q=&count=50&first=101",
"http://www.google.ch/search?q=&count=50&first=1",
"http://www.google.ch/search?q=&count=50&first=51",
"http://www.google.ch/search?q=&count=50&first=101",
"http://www.google.com.tr/search?q=&count=50&first=1",
"http://www.google.com.tr/search?q=&count=50&first=51",
"http://www.google.com.tr/search?q=&count=50&first=101",
"http://www.google.com.pr/search?q=&count=50&first=1",
"http://www.google.com.pr/search?q=&count=50&first=51",
"http://www.google.com.pr/search?q=&count=50&first=101",
"http://www.google.com.ar/search?q=&count=50&first=1",
"http://www.google.com.ar/search?q=&count=50&first=51",
"http://www.google.com.ar/search?q=&count=50&first=101",
"http://www.google.com.co/search?q=&count=50&first=1",
"http://www.google.com.co/search?q=&count=50&first=51",
"http://www.google.com.co/search?q=&count=50&first=101",
"http://www.google.com.es/search?q=&count=50&first=1",
"http://www.google.com.es/search?q=&count=50&first=51",
"http://www.google.com.es/search?q=&count=50&first=101",
"http://www.google.fi/search?q=&count=50&first=1",
"http://www.google.fi/search?q=&count=50&first=51",
"http://www.google.fi/search?q=&count=50&first=101",
"http://www.google.bo/search?q=&count=50&first=1",
"http://www.google.bo/search?q=&count=50&first=51",
"http://www.google.bo/search?q=&count=50&first=101",
"http://www.google.com.do/search?q=&count=50&first=1",
"http://www.google.com.do/search?q=&count=50&first=51",
"http://www.google.com.do/search?q=&count=50&first=101",
"http://www.google.gr/search?q=&count=50&first=1",
"http://www.google.gr/search?q=&count=50&first=51",
"http://www.google.gr/search?q=&count=50&first=101",
"http://www.google.com.hk/search?q=&count=50&first=1",
"http://www.google.com.hk/search?q=&count=50&first=51",
"http://www.google.com.hk/search?q=&count=50&first=101",
"http://www.google.com.hr/search?q=&count=50&first=1",
"http://www.google.com.hr/search?q=&count=50&first=51",
"http://www.google.com.hr/search?q=&count=50&first=101",
"http://www.google.com.mx/search?q=&count=50&first=1",
"http://www.google.com.mx/search?q=&count=50&first=51",
"http://www.google.com.mx/search?q=&count=50&first=101",
"http://www.google.com.my/search?q=&count=50&first=1",
"http://www.google.com.my/search?q=&count=50&first=51",
"http://www.google.com.my/search?q=&count=50&first=101",
"http://www.google.ph/search?q=&count=50&first=1",
"http://www.google.ph/search?q=&count=50&first=51",
"http://www.google.ph/search?q=&count=50&first=101",
"http://www.google.com.pr/search?q=&count=50&first=1",
"http://www.google.com.pr/search?q=&count=50&first=51",
"http://www.google.com.pr/search?q=&count=50&first=101",
"http://www.google.pt/search?q=&count=50&first=1",
"http://www.google.pt/search?q=&count=50&first=51",
"http://www.google.pt/search?q=&count=50&first=101",
"http://www.google.com.ro/search?q=&count=50&first=1",
"http://www.google.com.ro/search?q=&count=50&first=51",
"http://www.google.com.ro/search?q=&count=50&first=101",
"http://www.google.ru/search?q=&count=50&first=1",
"http://www.google.ru/search?q=&count=50&first=51",
"http://www.google.ru/search?q=&count=50&first=101",
"http://www.google.com.sa/search?q=&count=50&first=1",
"http://www.google.com.sa/search?q=&count=50&first=51",
"http://www.google.com.sa/search?q=&count=50&first=101",
"http://www.google.si/search?q=&count=50&first=1",
"http://www.google.si/search?q=&count=50&first=51",
"http://www.google.si/search?q=&count=50&first=101",
"http://www.google.sk/search?q=&count=50&first=1",
"http://www.google.sk/search?q=&count=50&first=51",
"http://www.google.sk/search?q=&count=50&first=101",
"http://www.google.com.ua/search?q=&count=50&first=1",
"http://www.google.com.ua/search?q=&count=50&first=51",
"http://www.google.com.ua/search?q=&count=50&first=101",
"http://www.google.com.uy/search?q=&count=50&first=1",
"http://www.google.com.uy/search?q=&count=50&first=51",
"http://www.google.com.uy/search?q=&count=50&first=101",
"http://www.google.vn/search?q=&count=50&first=1",
"http://www.google.vn/search?q=&count=50&first=51",
"http://www.google.vn/search?q=&count=50&first=101"}


def dorkscan(dork):
	for bing in binglist:
		bingg = bing.replace("&count",dork + "&count")
		try:
			r = requests.get(bingg)
			checktext = r.text
			checktext = checktext.replace("<strong>","")
			checktext = checktext.replace("</strong>","")
			checktext = checktext.replace('<span dir="ltr">','')
			checksites = re.findall('<cite>(.*?)</cite>',checktext)
			for sites in checksites:
				sites = sites.replace("http://","protocol1")
				sites = sites.replace("https://","protocol2")
				sites = sites + "/"
				site = sites[:sites.find("/")+0]
				site = site.replace("protocol1","http://")
				site = site.replace("protocol2","https://")
				if "http" in site:
					print(site + "/")
				else:
					print("http://" + site + "/")
				try:
					with open("sitelist.txt","a") as f:
						if "http" in site:
							f.write(site + "/" + "\n")
						else:
							f.write("http://" + site + "/" + "\n")
				except:
					pass
		except:
			pass


print(f'''╔══════════════════════════════════════════════════════╗
║{wh}Tools Laravel By {red}Ghofams{res}                              ║
║{gr}Mass Dorker{res}                                           ║
╚══════════════════════════════════════════════════════╝
''')

dorklist = input(f"{gr}Give Me Your DorkList/{red}Ghofams> {gr}${res} ")

try:
	dorks = open(dorklist, 'r').read().splitlines()
	print("[{}+{}] Scan started! Please wait... :)".format(settings.r,settings.y))
	pp = Pool(10)
	pr = pp.map(dorkscan,dorks)
except:
	print("[{}-{}] Dorklist not found!".format(settings.r,settings.y))