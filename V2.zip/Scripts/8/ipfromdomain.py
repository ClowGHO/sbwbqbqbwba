import sys,os,re,socket,binascii,time,json,random,threading,pprint,smtplib,telnetlib,os.path,hashlib,string,glob,sqlite3,argparse,marshal,base64,colorama,requests
from random import choice
from colorama import Fore,Back,init
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from platform import system
from time import strftime
from colorama import Fore,init, Style

def screen_clear():
    _ = os.system('cls')
bl = Fore.BLACK
wh = Fore.WHITE
yl = Fore.YELLOW
red = Fore.RED
res = Style.RESET_ALL
gr = Fore.GREEN
ble = Fore.BLUE

screen_clear()
print(f'''╔══════════════════════════════════════════════════════╗
║{wh}Tools Laravel By {red}Ghofams{res}                              ║
║{gr}Mass Ip To Domain{res}                                     ║
╚══════════════════════════════════════════════════════╝
''')

def getIP(site):
	
		site = i.strip()
		try:
			if 'http://' not in site:
				IP1 = socket.gethostbyname(site)
				print ("IP: "+IP1)
				open('ips.txt', 'a').write(IP1+'\n')
			elif 'http://' in site:
				url = site.replace('http://', '').replace('https://', '').replace('/', '')
				IP2 = socket.gethostbyname(url)
				print ("IP: "+IP2)
				open('ips.txt', 'a').write(IP2+'\n')
	
		except:
			pass
			
nam=input(f"{gr}Give Me Your Domain/{red}Ghofams> {gr}${res} ")
with open(nam) as f:
    for i in f:
        getIP(i)

		
